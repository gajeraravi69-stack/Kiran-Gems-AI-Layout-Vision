
export enum MetalType {
  YELLOW_GOLD = '18k Yellow Gold',
  WHITE_GOLD = '18k White Gold',
  ROSE_GOLD = '18k Rose Gold',
  SILVER = '925 Sterling Silver',
  PLATINUM = 'Platinum'
}

export enum EnvironmentStyle {
  UGC = 'UGC Style (Natural, Lifestyle)',
  STUDIO = 'Professional Studio (Clean, Minimal)',
  MODEL = 'On Model (Neck/Hand/Ear Try-on)',
  DISPLAY = 'Jewelry Box Display'
}

export interface GenerationResult {
  id: string;
  imageUrl: string;
  prompt: string;
  metal: MetalType;
  style: EnvironmentStyle;
  timestamp: number;
}
