
import React, { useState, useCallback } from 'react';
import ImageUploader from './components/ImageUploader';
import ControlPanel from './components/ControlPanel';
import { MetalType, EnvironmentStyle, GenerationResult } from './types';
import { GeminiService } from './services/geminiService';

const App: React.FC = () => {
  const [layoutImage, setLayoutImage] = useState<string | null>(null);
  const [refImage, setRefImage] = useState<string | null>(null);
  const [metal, setMetal] = useState<MetalType>(MetalType.YELLOW_GOLD);
  const [style, setStyle] = useState<EnvironmentStyle>(EnvironmentStyle.UGC);
  const [prompt, setPrompt] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [results, setResults] = useState<GenerationResult[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!layoutImage) return;

    setIsGenerating(true);
    setError(null);

    try {
      const gemini = new GeminiService();
      const generatedUrl = await gemini.generateJewelryImage(
        layoutImage,
        refImage,
        prompt,
        metal,
        style
      );

      const newResult: GenerationResult = {
        id: Date.now().toString(),
        imageUrl: generatedUrl,
        prompt: prompt || 'Kiran Precision Render',
        metal: metal,
        style: style,
        timestamp: Date.now()
      };

      setResults(prev => [newResult, ...prev]);
    } catch (err) {
      console.error(err);
      setError('Generation failed. Please check your layouts and try again.');
    } finally {
      setIsGenerating(false);
    }
  }, [layoutImage, refImage, prompt, metal, style]);

  return (
    <div className="min-h-screen text-slate-200 p-4 md:p-8">
      {/* Header */}
      <header className="max-w-7xl mx-auto mb-10 text-center">
        <div className="flex items-center justify-center gap-4 mb-3">
          <div className="relative">
            <i className="fa-solid fa-gem text-amber-500 text-4xl"></i>
            <i className="fa-solid fa-sparkles absolute -top-2 -right-2 text-amber-200 text-lg animate-pulse"></i>
          </div>
          <h1 className="luxury-text text-4xl md:text-6xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-amber-100 via-amber-400 to-amber-700">
            Kiran Gems AI Layout Vision
          </h1>
        </div>
        <p className="text-slate-400 max-w-2xl mx-auto text-xs md:text-sm tracking-[0.2em] uppercase font-light">
          Precision Shape Preservation & Structural Jewelry Rendering
        </p>
      </header>

      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left Side: Controls */}
        <div className="lg:col-span-5 space-y-6">
          <section className="glass-panel p-8 rounded-[2.5rem] border-amber-500/20 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
            <div className="flex items-center justify-between mb-8 border-b border-slate-700/50 pb-4">
              <h2 className="text-2xl font-bold luxury-text tracking-wide flex items-center gap-3">
                <i className="fa-solid fa-wand-magic-sparkles text-amber-500"></i>
                Design Studio
              </h2>
              <span className="text-[10px] px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/40 text-amber-400 uppercase tracking-[0.2em] font-black">Precision Mode</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              <ImageUploader 
                title="1. Diamond Layout"
                description="Upload technical cutout"
                onImageSelect={(b64) => setLayoutImage(b64 || null)} 
                previewUrl={layoutImage}
                icon="fa-object-group"
                height="h-44"
              />
              <ImageUploader 
                title="2. Style Reference"
                description="Upload reference image"
                onImageSelect={(b64) => setRefImage(b64 || null)} 
                previewUrl={refImage}
                icon="fa-camera-retro"
                height="h-44"
              />
            </div>
            
            <ControlPanel
              metal={metal}
              setMetal={setMetal}
              style={style}
              setStyle={setStyle}
              prompt={prompt}
              setPrompt={setPrompt}
              onGenerate={handleGenerate}
              isGenerating={isGenerating}
              canGenerate={!!layoutImage}
            />
            
            {error && (
              <div className="mt-6 p-4 bg-red-500/10 border border-red-500/40 rounded-xl text-red-200 text-xs flex items-center gap-3 animate-pulse uppercase tracking-widest font-bold">
                <i className="fa-solid fa-triangle-exclamation text-lg"></i>
                {error}
              </div>
            )}
            
            <p className="mt-4 text-[10px] text-slate-500 text-center uppercase tracking-widest leading-relaxed">
              Our AI is strictly configured to preserve your stone shapes 1:1 from the layout image.
            </p>
          </section>
        </div>

        {/* Right Side: Results */}
        <div className="lg:col-span-7 space-y-6">
          <section className="glass-panel p-8 rounded-[2.5rem] h-full flex flex-col min-h-[650px] border-white/5 shadow-2xl relative overflow-hidden">
            <h2 className="text-2xl font-bold luxury-text tracking-wide mb-8 flex items-center gap-3 relative z-10">
              <i className="fa-solid fa-camera-viewfinder text-amber-500"></i>
              Precision Gallery
            </h2>

            {results.length === 0 && !isGenerating ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-500 border-2 border-dashed border-slate-800 rounded-3xl bg-slate-900/40 transition-all">
                <div className="relative mb-6 text-center">
                  <i className="fa-solid fa-gem text-7xl opacity-5"></i>
                  <i className="fa-solid fa-expand absolute inset-0 text-amber-500/10 text-4xl mt-4"></i>
                </div>
                <p className="text-lg font-medium opacity-40 uppercase tracking-widest">Awaiting Masterpiece</p>
                <p className="text-xs mt-3 opacity-30 italic max-w-xs text-center px-4">Stones will be rendered with exact layout geometry and chosen metal settings.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 overflow-y-auto pr-4 custom-scrollbar relative z-10">
                {isGenerating && (
                  <div className="aspect-square glass-panel rounded-3xl flex flex-col items-center justify-center border-2 border-amber-500/60 animate-pulse bg-amber-500/10 relative overflow-hidden shadow-[0_0_30px_rgba(245,158,11,0.2)]">
                    <div className="w-16 h-16 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mb-6"></div>
                    <p className="text-amber-200 font-bold uppercase tracking-[0.2em] text-xs">Preserving Shapes...</p>
                    <p className="text-slate-400 text-[10px] mt-4 px-10 text-center uppercase tracking-widest leading-relaxed">Clamping stones into solid {metal} while maintaining exact geometry</p>
                  </div>
                )}
                {results.map((res) => (
                  <div key={res.id} className="group relative bg-black/40 rounded-[2rem] overflow-hidden border border-white/10 hover:border-amber-500/60 transition-all duration-700 shadow-2xl hover:shadow-amber-500/30">
                    <div className="aspect-square overflow-hidden bg-black">
                      <img src={res.imageUrl} alt="Generated Jewelry" className="w-full h-full object-cover transition-transform duration-[3000ms] group-hover:scale-105" />
                    </div>
                    
                    <div className="absolute top-4 left-4 flex gap-2">
                      <span className="bg-black/70 backdrop-blur-md text-amber-400 text-[9px] font-black px-3 py-1 rounded-full border border-amber-500/30 uppercase tracking-[0.2em] shadow-lg">
                        {res.metal.split(' ')[1]} {res.metal.split(' ')[2] || 'Gold'}
                      </span>
                    </div>
                    
                    <div className="p-6 bg-gradient-to-t from-black via-slate-950/98 to-slate-900/95 border-t border-white/5 backdrop-blur-xl">
                      <div className="flex justify-between items-center">
                        <div className="flex-1">
                          <h3 className="text-amber-100 text-[13px] font-black uppercase tracking-[0.1em] mb-1 truncate">{res.metal} Setting</h3>
                          <div className="flex items-center gap-2 opacity-60">
                            <i className="fa-solid fa-shapes text-[9px] text-amber-500"></i>
                            <p className="text-slate-300 text-[9px] font-bold tracking-[0.15em] uppercase truncate">Shape-Preserved Render</p>
                          </div>
                        </div>
                        <a 
                          href={res.imageUrl} 
                          download={`kiran-gems-${res.id}.png`}
                          className="bg-amber-600/10 hover:bg-amber-500 text-amber-500 hover:text-white w-10 h-10 rounded-xl flex items-center justify-center transition-all shadow-lg active:scale-90 border border-amber-500/40"
                        >
                          <i className="fa-solid fa-download"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </main>

      {/* Footer Info */}
      <footer className="max-w-7xl mx-auto mt-16 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-slate-600 text-[10px] uppercase tracking-[0.4em] font-black">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]"></div>
          <p>© 2024 Kiran Gems AI Vision • Industrial Layout Rendering</p>
        </div>
        <div className="flex gap-10">
          <span className="hover:text-amber-500 transition-colors cursor-help">Zero-Change Geometry</span>
          <span className="hover:text-amber-500 transition-colors cursor-help">Refined Metal Setting</span>
          <span className="hover:text-amber-500 transition-colors cursor-help">Kiran Quality</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
