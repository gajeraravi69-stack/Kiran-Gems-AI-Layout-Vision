
import React from 'react';
import { MetalType, EnvironmentStyle } from '../types';

interface ControlPanelProps {
  metal: MetalType;
  setMetal: (m: MetalType) => void;
  style: EnvironmentStyle;
  setStyle: (s: EnvironmentStyle) => void;
  prompt: string;
  setPrompt: (p: string) => void;
  onGenerate: () => void;
  isGenerating: boolean;
  canGenerate: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  metal, setMetal, style, setStyle, prompt, setPrompt, onGenerate, isGenerating, canGenerate
}) => {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Metal Type</label>
        <div className="grid grid-cols-2 gap-2">
          {Object.values(MetalType).map((m) => (
            <button
              key={m}
              onClick={() => setMetal(m)}
              className={`px-3 py-2 rounded-lg text-xs font-medium border transition-all ${
                metal === m 
                ? 'bg-amber-500/20 border-amber-500 text-amber-200 shadow-[0_0_15px_rgba(245,158,11,0.2)]' 
                : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:border-slate-500'
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Scene Style</label>
        <select
          value={style}
          onChange={(e) => setStyle(e.target.value as EnvironmentStyle)}
          className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
        >
          {Object.values(EnvironmentStyle).map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Custom Instructions (Prompt)</label>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., Make it look like a high-end Instagram UGC post, lying on a silk bedsheet with soft sunlight..."
          className="w-full h-32 bg-slate-800/50 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500/50 resize-none"
        />
      </div>

      <button
        onClick={onGenerate}
        disabled={!canGenerate || isGenerating}
        className={`w-full py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-2 ${
          !canGenerate || isGenerating
          ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
          : 'bg-gradient-to-r from-amber-600 to-amber-400 text-white hover:from-amber-500 hover:to-amber-300 shadow-[0_0_20px_rgba(217,119,6,0.3)] active:scale-[0.98]'
        }`}
      >
        {isGenerating ? (
          <>
            <i className="fa-solid fa-circle-notch animate-spin"></i>
            Crafting...
          </>
        ) : (
          <>
            <i className="fa-solid fa-wand-magic-sparkles"></i>
            Generate Jewelry
          </>
        )}
      </button>
    </div>
  );
};

export default ControlPanel;
