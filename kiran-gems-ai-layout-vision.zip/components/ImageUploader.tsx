
import React from 'react';

interface ImageUploaderProps {
  onImageSelect: (base64: string) => void;
  previewUrl: string | null;
  title: string;
  description: string;
  icon?: string;
  height?: string;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ 
  onImageSelect, 
  previewUrl, 
  title, 
  description, 
  icon = "fa-gem",
  height = "h-48"
}) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        onImageSelect(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="w-full">
      <label className="block text-xs font-bold text-amber-500/80 uppercase tracking-widest mb-2">
        {title}
      </label>
      <div className="relative group">
        <div className={`w-full ${height} border-2 border-dashed rounded-2xl flex flex-col items-center justify-center transition-all duration-300 ${
          previewUrl ? 'border-amber-500/50 bg-amber-500/5' : 'border-slate-700 bg-slate-800/20 hover:border-amber-500/30'
        } glass-panel overflow-hidden`}>
          {previewUrl ? (
            <img 
              src={`data:image/png;base64,${previewUrl}`} 
              alt="Preview" 
              className="w-full h-full object-contain p-2"
            />
          ) : (
            <div className="text-center p-4">
              <i className={`fa-solid ${icon} text-3xl text-slate-500 mb-2 group-hover:text-amber-500/50 transition-colors`}></i>
              <p className="text-slate-400 text-[11px] font-medium leading-tight">{description}</p>
              <p className="text-slate-600 text-[9px] mt-1 italic">Click or drag to upload</p>
            </div>
          )}
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          {previewUrl && (
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onImageSelect('');
                }}
                className="bg-red-500/80 text-white p-2 rounded-lg hover:bg-red-600 transition-colors shadow-lg"
              >
                <i className="fa-solid fa-trash-can text-[10px]"></i>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageUploader;
