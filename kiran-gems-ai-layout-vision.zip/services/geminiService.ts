
import { GoogleGenAI } from "@google/genai";
import { MetalType, EnvironmentStyle } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }

  async generateJewelryImage(
    layoutImage: string,
    refImage: string | null,
    userPrompt: string,
    metal: MetalType,
    style: EnvironmentStyle
  ): Promise<string> {
    const model = 'gemini-2.5-flash-image';

    const systemPrompt = `
      ROLE: Precision Jewelry CAD Renderer for "Kiran Gems".
      
      STRICT REQUIREMENT: STONE SHAPE PRESERVATION (MANDATORY).
      
      1. NO STONE SUBSTITUTION: You MUST preserve the EXACT SHAPES and SILHOUETTES of every stone in the "Diamond Layout" image. 
         - If a stone is a Marquise, it MUST stay a Marquise. 
         - If it is a Pear, it MUST stay a Pear. 
         - Do NOT change shapes to make them look "better." The geometry in the Layout Image is FINAL.
      
      2. EXACT PLACEMENT: Do not move, rotate, or re-arrange any stones. The layout provided is the technical master.
      
      3. PHYSICAL SETTING:
         - Every stone must be SECURELY SET in ${metal}.
         - Use shared prongs, v-prongs, or channel settings. 
         - Connect all stones with a solid ${metal} structure (the gallery/base). No floating stones.
      
      4. STYLE INSPIRATION:
         - Use the "Style Reference" image (if provided) ONLY for the mood, lighting, and how the metal settings are finished. 
         - Do NOT copy the stone shapes from the Reference Image. ONLY copy the stone shapes from the "Diamond Layout" image.
      
      5. FINISH & LIGHTING:
         - Render premium ${metal} with high-gloss reflections.
         - High-brilliance Kiran Gems diamond texture within the existing shapes.
         - Environment: ${style}.
         - User Request: ${userPrompt}
      
      Output ONLY the final photorealistic masterpiece. Ensure 1:1 shape accuracy to the layout image.
    `;

    const parts: any[] = [
      {
        inlineData: {
          data: layoutImage,
          mimeType: 'image/png',
        },
      },
      {
        text: systemPrompt
      },
    ];

    if (refImage) {
      parts.push({
        inlineData: {
          data: refImage,
          mimeType: 'image/png',
        },
      });
      parts.push({ text: "STYLE REFERENCE: Use this ONLY for the metal finish and photography style. IGNORE the stone shapes in this image." });
    }

    const response = await this.ai.models.generateContent({
      model: model,
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }

    throw new Error("No image data returned from the AI.");
  }
}
